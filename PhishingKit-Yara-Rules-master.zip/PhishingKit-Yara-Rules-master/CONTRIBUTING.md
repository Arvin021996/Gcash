## Contributing

Pull requests and issues with suggestions are welcome! Please try to keep your changes cleanly formatted and alphabetized.

Format name of file to use: "PK_NameOfBrand_SpecificNameOfKitVersion.yar"

Choose a specific name of kit version with a specific string (name of actor, name of file, name of kit, version, ...) found in the Phishing kit. 

By submitting a PR you agree to release your contributions under the terms of the [LICENSE](LICENSE).
